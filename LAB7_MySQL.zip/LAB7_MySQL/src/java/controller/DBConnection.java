package controller;

import java.sql.*;
import model.Food;

public class DBConnection {

    // เชื่อมต่อ DB แบบ UTF-8
    private Connection getConnection() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/srikai?useSSL=false&serverTimezone=UTC&useUnicode=true&characterEncoding=UTF-8",
                "root",
                "Matth_wwww5900"
        );
    }

    // Insert Food แบบปลอดภัย
    public boolean insertNewFood(Food food) {
        boolean result = false;
        String query = "INSERT INTO food (id, foodName, foodType, nutrients, hotLevel, foodPrice) "
                     + "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, food.getId());
            ps.setString(2, food.getFoodName());
            ps.setString(3, food.getFoodType());
            ps.setString(4, food.getNutrients());
            ps.setString(5, food.getHotLevel());
            ps.setBigDecimal(6, new java.math.BigDecimal(food.getFoodPrice()));

            int i = ps.executeUpdate();
            result = (i > 0);

        } catch (Exception e) {
            System.out.println("Insert error: " + e);
        }

        return result;
    }

    // Retrieve ข้อมูลทั้งหมดจาก table food
    public void testRetrieve() {
        String query = "SELECT * FROM food";

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                System.out.println(
                    "ID: " + rs.getString("id") +
                    ", Name: " + rs.getString("foodName") +
                    ", Type: " + rs.getString("foodType") +
                    ", Nutrients: " + rs.getString("nutrients") +
                    ", HotLevel: " + rs.getString("hotLevel") +
                    ", Price: " + rs.getBigDecimal("foodPrice")
                );
            }

        } catch (Exception e) {
            System.out.println("Retrieve error: " + e);
        }
    }
}
