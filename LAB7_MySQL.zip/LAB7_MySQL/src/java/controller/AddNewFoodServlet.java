import controller.DBConnection;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.Food;

@WebServlet(urlPatterns = {"/AddNewFoodServlet"})
public class AddNewFoodServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");  // ✅ ตั้งค่า request encoding

        String foodName = request.getParameter("foodName");
        String foodType = request.getParameter("foodType");
        String nutrient[] = request.getParameterValues("nutrient");
        String hotLevel = request.getParameter("hotLevel");
        int foodPrice = Integer.parseInt(request.getParameter("foodPrice"));

        // รวม nutrients แบบไม่มี ", " ตัวสุดท้าย
        String nutrients = "";
        if (nutrient != null) {
            for (String n : nutrient) {
                nutrients += n + ", ";
            }
            if (nutrients.endsWith(", ")) {
                nutrients = nutrients.substring(0, nutrients.length() - 2);
            }
        }

        // สร้าง Food object
        Food food = new Food();
        food.setId("1");  // ถ้า DB auto-increment สามารถปล่อยให้ DB กำหนด
        food.setFoodName(foodName);
        food.setFoodType(foodType);
        food.setNutrients(nutrients);
        food.setHotLevel(hotLevel);
        food.setFoodPrice(foodPrice);

        // บันทึกลง Database
        DBConnection db = new DBConnection();
        if (!db.insertNewFood(food)) {
            System.out.println(">>> ไม่สามารถบันทึกข้อมูลลงฐานข้อมูลได้");
        }

        // จัดการ Session
        HttpSession session = request.getSession();
        if (session != null) {
            session.removeAttribute("food");
        }
        session.setAttribute("food", food);

        // Redirect ไปหน้า Success
        response.sendRedirect("AddNewFoodSuccess.jsp");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Add New Food Servlet - รองรับภาษาไทย";
    }
}
